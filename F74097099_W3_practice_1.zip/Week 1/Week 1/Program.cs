﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int day, month;
            string[] dayname =new String[] { "Mon","Tue", "Wed" ,"Thu" ,"Fri" ,"Sat" ,"Sun" };
            Console.Write("1月1日星期幾(1-7) : ");
            try
            {
                day = int.Parse(Console.ReadLine());
                if (day < 1 || day > 7)
                {
                    Console.Write("超出範圍");
                    Console.ReadLine();
                }
                else
                {
                    Console.Write("從幾月開始(1-12) : ");
                    month = int.Parse(Console.ReadLine());
                    if (month < 1 || month > 12)
                    {
                        Console.Write("超出範圍");
                        Console.ReadLine();
                    }
                    else
                    {
                        string[] monArr = new String[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
                        int[] monNum = new int[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
                        int currentmon = month;
                        int count = day;
                        int space = 0;//No need space in the beginning
                        while (currentmon <= 12)
                        {
                            if (space == 1)
                                Console.WriteLine();
                            Console.WriteLine(monArr[currentmon - 1]);
                            for (int i = 0; i < 7; i++)
                            {
                                Console.Write("{0,-4}", dayname[i]);//Allign To Left
                            }
                            Console.WriteLine();
                            if (count % 7 == 0) //If Start From Sunday
                            {
                                Console.Write("                        ");
                            }
                            for (int i = 1; i < (count % 7); i++)
                            {
                                Console.Write("    ");//Find the first day of the month
                            }
                            for (int j = 1; j <= monNum[currentmon - 1]; j++)
                            {
                                Console.Write("{0,3}", j);
                                Console.Write(" ");
                                if ((++count - 1) % 7 == 0 && j!= monNum[currentmon - 1])
                                    Console.WriteLine();//Reach Sunday,Need to Change Line
                            }
                            space = 1;
                            currentmon++;//Change Month
                            Console.WriteLine();
                        }

                        Console.ReadLine();
                    }
                }
            }
            catch(FormatException ex)
            {
                Console.Write("請輸入範圍內的整數");
                Console.ReadLine();
            }
        }
    }
}