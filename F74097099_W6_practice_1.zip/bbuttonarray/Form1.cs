﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bbuttonarray
{
    public partial class Form1 : Form
    {

        int h, w;
        Button[,] a = new Button[20, 15];
        Button[,] b = new Button[20, 15];
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        public void seven(int n, Button[,] btn)
        {
            switch (n)
            {
                case 1:
                    {
                        for (int i = 1; i < (h - 1) / 2; i++) btn[i, 0].BackColor = Color.Blue;
                        break;
                    }

                case 2:
                    {
                        for (int j = 1; j < w - 1; j++) btn[0, j].BackColor = Color.Blue;
                        break;
                    }

                case 3:
                    {
                        for (int i = 1; i < (h - 1) / 2; i++) btn[i, w - 1].BackColor = Color.Blue;
                        break;
                    }

                case 4:
                    {
                        for (int i = 1 + (h - 1) / 2; i < h - 1; i++) btn[i, w - 1].BackColor = Color.Blue;
                        break;
                    }

                case 5:
                    {
                        for (int j = 1; j < w - 1; j++) btn[h - 1, j].BackColor = Color.Blue;
                        break;
                    }

                case 6:
                    {
                        for (int i = 1 + (h - 1) / 2; i < h - 1; i++) btn[i, 0].BackColor = Color.Blue;
                        break;
                    }

                case 7:
                    {
                        for (int j = 1; j < w - 1; j++) btn[ (h - 1) / 2, j].BackColor = Color.Blue;
                        break;
                    }
            }
        }

        private void CONFIRM_Click(object sender, EventArgs e)
        {

            if ((int.TryParse(textBox1.Text, out h)) == false)
            {
                MessageBox.Show("Please enter a number", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            else if ((int.TryParse(textBox2.Text, out w)) == false)
            {
                MessageBox.Show("Please enter a number", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            //out of range
            else if ((h < 7) || (h > 15) || (w < 5) || (w > 10))
            {
                MessageBox.Show("Please enter a number within the range", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            //width is odd number
            else if ((h % 2) == 0)
            {
                MessageBox.Show("The height should not be an even number", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


            else
            {
                textBox3.Enabled = true;
                flowLayoutPanel1.Controls.Clear();
                flowLayoutPanel2.Controls.Clear();

                int wid = 200 / w;
                int hei = 300 / h;

                for (int i = 0; i < h; i++)
                {
                    for (int j = 0; j < w; j++)
                    {
                        a[i, j] = new Button();
                        a[i, j].Size = new Size(wid, hei);
                        a[i, j].Margin = new Padding(1);
                        a[i, j].BackColor = Color.White;
                        flowLayoutPanel1.Controls.Add(a[i, j]);

                        b[i, j] = new Button();
                        b[i, j].Size = new Size(wid, hei);
                        b[i, j].Margin = new Padding(1);
                        b[i, j].BackColor = Color.White;
                        flowLayoutPanel2.Controls.Add(b[i, j]);
                    }
                }

                string s = textBox3.Text;

                if (s != "")
                {
                    if (s.Length == 1)
                    {
                        if (s[0] != '-') for (int i = 1; i <= 6; i++) seven(i, a);//0

                        switch (s[0])
                        {
                            case '0':
                                {
                                    for (int i = 1; i <= 6; i++) seven(i, b);//0                            
                                    break;
                                }

                            case '1':
                                {
                                    for (int i = 3; i <= 4; i++) seven(i, b);
                                    break;
                                }

                            case '2':
                                {
                                    seven(2, b);
                                    seven(3, b);
                                    seven(7, b);
                                    seven(6, b);
                                    seven(5, b);
                                    break;
                                }

                            case '3':
                                {
                                    for (int i = 2; i <= 5; i++) seven(i, b);
                                    seven(7, b);
                                    break;
                                }

                            case '4':
                                {
                                    seven(1, b);
                                    seven(7, b);
                                    seven(3, b);
                                    seven(4, b);
                                    break;
                                }

                            case '5':
                                {
                                    seven(1, b);
                                    seven(7, b);
                                    seven(2, b);
                                    seven(4, b);
                                    seven(5, b);
                                    break;
                                }

                            case '6':
                                {
                                    seven(1, b);
                                    seven(2, b);
                                    for (int i = 4; i <= 7; i++) seven(i, b);
                                    break;
                                }

                            case '7':
                                {
                                    for (int i = 2; i <= 4; i++) seven(i, b);
                                    break;
                                }

                            case '8':
                                {
                                    for (int i = 1; i <= 7; i++) seven(i, b);
                                    break;
                                }

                            case '9':
                                {
                                    for (int i = 1; i <= 5; i++) seven(i, b);
                                    seven(7, b);
                                    break;
                                }

                            case '-':
                                {
                                    seven(7, a);
                                    break;
                                }
                        }
                    }



                    else if (s.Length == 2)
                    {
                        switch (s[1])
                        {
                            case '0':
                                {
                                    for (int i = 1; i <= 6; i++) seven(i, b);//0                            
                                    break;
                                }

                            case '1':
                                {
                                    for (int i = 3; i <= 4; i++) seven(i, b);
                                    break;
                                }

                            case '2':
                                {
                                    seven(2, b);
                                    seven(3, b);
                                    seven(7, b);
                                    seven(6, b);
                                    seven(5, b);
                                    break;
                                }

                            case '3':
                                {
                                    for (int i = 2; i <= 5; i++) seven(i, b);
                                    seven(7, b);
                                    break;
                                }

                            case '4':
                                {
                                    seven(1, b);
                                    seven(7, b);
                                    seven(3, b);
                                    seven(4, b);
                                    break;
                                }

                            case '5':
                                {
                                    seven(1, b);
                                    seven(7, b);
                                    seven(2, b);
                                    seven(4, b);
                                    seven(5, b);
                                    break;
                                }

                            case '6':
                                {
                                    seven(1, b);
                                    seven(2, b);
                                    for (int i = 4; i <= 7; i++) seven(i, b);
                                    break;
                                }

                            case '7':
                                {
                                    for (int i = 2; i <= 4; i++) seven(i, b);
                                    break;
                                }

                            case '8':
                                {
                                    for (int i = 1; i <= 7; i++) seven(i, b);
                                    break;
                                }

                            case '9':
                                {
                                    for (int i = 1; i <= 5; i++) seven(i, b);
                                    seven(7, b);
                                    break;
                                }

                        }

                        switch (s[0])
                        {
                            case '0':
                                {
                                    for (int i = 1; i <= 6; i++) seven(i, a);//0                            
                                    break;
                                }

                            case '1':
                                {
                                    for (int i = 3; i <= 4; i++) seven(i, a);
                                    break;
                                }

                            case '2':
                                {
                                    seven(2, a);
                                    seven(3, a);
                                    seven(7, a);
                                    seven(6, a);
                                    seven(5, a);
                                    break;
                                }

                            case '3':
                                {
                                    for (int i = 2; i <= 5; i++) seven(i, a);
                                    seven(7, a);
                                    break;
                                }

                            case '4':
                                {
                                    seven(1, a);
                                    seven(7, a);
                                    seven(3, a);
                                    seven(4, a);
                                    break;
                                }

                            case '5':
                                {
                                    seven(1, a);
                                    seven(7, a);
                                    seven(2, a);
                                    seven(4, a);
                                    seven(5, a);
                                    break;
                                }

                            case '6':
                                {
                                    seven(1, a);
                                    seven(2, a);
                                    for (int i = 4; i <= 7; i++) seven(i, a);
                                    break;
                                }

                            case '7':
                                {
                                    for (int i = 2; i <= 4; i++) seven(i, a);
                                    break;
                                }

                            case '8':
                                {
                                    for (int i = 1; i <= 7; i++) seven(i, a);
                                    break;
                                }

                            case '9':
                                {
                                    for (int i = 1; i <= 5; i++) seven(i, a);
                                    seven(7, a);
                                    break;
                                }

                            case '-':
                                {
                                    seven(7, a);
                                    break;
                                }
                        }
                    }

                }
            }
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel2_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            foreach (Button a in flowLayoutPanel1.Controls) a.BackColor = Color.White;          
            foreach (Button b in flowLayoutPanel2.Controls) b.BackColor = Color.White;
            
            string s = textBox3.Text;

            if (s != "")
            {
                if (s.Length == 1)
                {
                    if(s[0]!='-') for (int i = 1; i <= 6; i++) seven(i, a);//0

                    switch (s[0])
                    {
                        case '0':
                            {
                                for (int i = 1; i <= 6; i++) seven(i, b);//0                            
                                break;
                            }

                        case '1':
                            {
                                for (int i = 3; i <= 4; i++) seven(i, b);
                                break;
                            }

                        case '2':
                            {
                                seven(2, b);
                                seven(3, b);
                                seven(7, b);
                                seven(6, b);
                                seven(5, b);
                                break;
                            }

                        case '3':
                            {
                                for (int i = 2; i <= 5; i++) seven(i, b);
                                seven(7, b);
                                break;
                            }

                        case '4':
                            {
                                seven(1, b);
                                seven(7, b);
                                seven(3, b);
                                seven(4, b);
                                break;
                            }

                        case '5':
                            {
                                seven(1, b);
                                seven(7, b);
                                seven(2, b);
                                seven(4, b);
                                seven(5, b);
                                break;
                            }

                        case '6':
                            {
                                seven(1, b);
                                seven(2, b);
                                for (int i = 4; i <= 7; i++) seven(i, b);
                                break;
                            }

                        case '7':
                            {
                                for (int i = 2; i <= 4; i++) seven(i, b);
                                break;
                            }

                        case '8':
                            {
                                for (int i = 1; i <= 7; i++) seven(i, b);
                                break;
                            }

                        case '9':
                            {
                                for (int i = 1; i <= 5; i++) seven(i, b);
                                seven(7, b);
                                break;
                            }

                        case '-':
                            {
                                seven(7, a);
                                break;
                            }
                    }
                }



                else if (s.Length == 2)
                {
                    switch (s[1])
                    {
                        case '0':
                            {
                                for (int i = 1; i <= 6; i++) seven(i, b);//0                            
                                break;
                            }

                        case '1':
                            {
                                for (int i = 3; i <= 4; i++) seven(i, b);
                                break;
                            }

                        case '2':
                            {
                                seven(2, b);
                                seven(3, b);
                                seven(7, b);
                                seven(6, b);
                                seven(5, b);
                                break;
                            }

                        case '3':
                            {
                                for (int i = 2; i <= 5; i++) seven(i, b);
                                seven(7, b);
                                break;
                            }

                        case '4':
                            {
                                seven(1, b);
                                seven(7, b);
                                seven(3, b);
                                seven(4, b);
                                break;
                            }

                        case '5':
                            {
                                seven(1, b);
                                seven(7, b);
                                seven(2, b);
                                seven(4, b);
                                seven(5, b);
                                break;
                            }

                        case '6':
                            {
                                seven(1, b);
                                seven(2, b);
                                for (int i = 4; i <= 7; i++) seven(i, b);
                                break;
                            }

                        case '7':
                            {
                                for (int i = 2; i <= 4; i++) seven(i, b);
                                break;
                            }

                        case '8':
                            {
                                for (int i = 1; i <= 7; i++) seven(i, b);
                                break;
                            }

                        case '9':
                            {
                                for (int i = 1; i <= 5; i++) seven(i, b);
                                seven(7, b);
                                break;
                            }

                    }

                    switch (s[0])
                    {
                        case '0':
                            {
                                for (int i = 1; i <= 6; i++) seven(i, a);//0                            
                                break;
                            }

                        case '1':
                            {
                                for (int i = 3; i <= 4; i++) seven(i, a);
                                break;
                            }

                        case '2':
                            {
                                seven(2, a);
                                seven(3, a);
                                seven(7, a);
                                seven(6, a);
                                seven(5, a);
                                break;
                            }

                        case '3':
                            {
                                for (int i = 2; i <= 5; i++) seven(i, a);
                                seven(7, a);
                                break;
                            }

                        case '4':
                            {
                                seven(1, a);
                                seven(7, a);
                                seven(3, a);
                                seven(4, a);
                                break;
                            }

                        case '5':
                            {
                                seven(1, a);
                                seven(7, a);
                                seven(2, a);
                                seven(4, a);
                                seven(5, a);
                                break;
                            }

                        case '6':
                            {
                                seven(1, a);
                                seven(2, a);
                                for (int i = 4; i <= 7; i++) seven(i, a);
                                break;
                            }

                        case '7':
                            {
                                for (int i = 2; i <= 4; i++) seven(i, a);
                                break;
                            }

                        case '8':
                            {
                                for (int i = 1; i <= 7; i++) seven(i, a);
                                break;
                            }

                        case '9':
                            {
                                for (int i = 1; i <= 5; i++) seven(i, a);
                                seven(7, a);
                                break;
                            }

                        case '-':
                            {
                                seven(7, a);
                                break;
                            }
                    }
                }

            }

        }
    }
}



