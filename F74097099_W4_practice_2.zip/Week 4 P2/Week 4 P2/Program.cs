﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_4_P2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Please enter the size of the maze(bottom, height):");
            string[] read = Console.ReadLine().Split(',');
            int y = int.Parse(read[0]), x = int.Parse(read[1]);
            Console.WriteLine("Input the maze map:");
            char[,] map = new char[x, y];
            int[,] draft = new int[x, y];
            int[,,] backtrace = new int[x, y, 2];
            int startX = 0, startY = 0;
            int endX = 0, endY = 0;
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    map[i, j] = (char)Console.Read();
                    if (map[i, j] == ' ') //Road
                    {
                        draft[i, j] = -1;
                    }
                    else // Wall
                    {
                        draft[i, j] = -10;
                    }
                    if (map[i, j] == '0') //Starting Point
                    {
                        startX = i; 
                        startY = j;
                        draft[i, j] = 0;
                    }
                    if (map[i, j] == 'X') //Ending Point
                    {
                        endX = i;
                        endY = j;
                        draft[i, j] = -1;
                    }
                }
                Console.ReadLine();
            }
            Console.WriteLine();
            Queue<int> qux = new Queue<int>();
            Queue<int> quy = new Queue<int>();
            qux.Enqueue(startX); //Add Start Point into Queue
            quy.Enqueue(startY);
            int nowx, nowy;
            bool win = false;
            while (qux.Count() != 0)
            {
                nowx = qux.Dequeue(); //Current Point
                nowy = quy.Dequeue();
                if (map[nowx, nowy] == 'X') //Reach End Point
                {
                    win = true;
                    break;
                }
                if (nowx > 0 && draft[nowx - 1, nowy] == -1) //Move Left && Road && Valid
                {
                    qux.Enqueue(nowx - 1); //Add the point after moved into Queue
                    quy.Enqueue(nowy);
                    draft[nowx - 1, nowy] = draft[nowx, nowy] + 1; //Store Step into draft
                    backtrace[nowx - 1, nowy, 0] = nowx;
                    backtrace[nowx - 1, nowy, 1] = nowy;
                }
                if (nowx < x - 1 && draft[nowx + 1, nowy] == -1) //Move Right && Road && Valid
                {
                    qux.Enqueue(nowx + 1);
                    quy.Enqueue(nowy);
                    draft[nowx + 1, nowy] = draft[nowx, nowy] + 1;
                    backtrace[nowx + 1, nowy, 0] = nowx;
                    backtrace[nowx + 1, nowy, 1] = nowy;
                }
                if (nowy > 0 && draft[nowx, nowy - 1] == -1) //Move Up && Road && Valid
                {
                    qux.Enqueue(nowx);
                    quy.Enqueue(nowy - 1);
                    draft[nowx, nowy - 1] = draft[nowx, nowy] + 1;
                    backtrace[nowx, nowy - 1, 0] = nowx;
                    backtrace[nowx, nowy - 1, 1] = nowy;
                }
                if (nowy < y - 1 && draft[nowx, nowy + 1] == -1) //Move Down && Road && Valid
                {
                    qux.Enqueue(nowx);
                    quy.Enqueue(nowy + 1);
                    draft[nowx, nowy + 1] = draft[nowx, nowy] + 1;
                    backtrace[nowx, nowy + 1, 0] = nowx;
                    backtrace[nowx, nowy + 1, 1] = nowy;
                }
            }
            Console.WriteLine("Output:");
            if (win)
            {
                for (int i = backtrace[endX, endY, 0], j = backtrace[endX, endY, 1]; i != startX || j != startY;) //Print from end point
                {
                    map[i, j] = '*';
                    int t = i;
                    i = backtrace[t, j, 0]; //Previous Point
                    j = backtrace[t, j, 1];
                }
                for (int i = 0; i < x; i++)
                {
                    for (int j = 0; j < y; j++)
                    {
                        Console.Write(map[i, j]); //Print Map
                    }
                    Console.WriteLine();
                }
                Console.WriteLine(draft[endX, endY] - 1); //Step Count
            }
            else
            {
                for (int i = 0; i < x; i++)
                {
                    for (int j = 0; j < y; j++)
                    {
                        Console.Write(map[i, j]);
                    }
                    Console.WriteLine();
                }
                Console.WriteLine("No path");
            }
            Console.ReadKey();
        }

    }
}
