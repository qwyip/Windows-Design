﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Memes
{
    public partial class Form1 : Form
    {
        static Label text;
        static bool bold = false;
        static bool italic = false;

        public Form1()
        {
            InitializeComponent();
            text = new Label();
            text.size = 12;
            text.Family = new FontFamily("Stencil");
            text.Style = FontStyle.Regular;
            txtShow.Font = new Font(text.Family, text.size, text.Style);
            txtShow.Location = new Point(39, text.YLocation);
            txtShow.TextAlign = text.Alignment;
        }

        int current;
      
        private void FigShow()
        {
            pic.Image = Image.FromFile(@"..\..\pic\pic_0"+current+".png");
            pic.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            current = 1;
            FigShow();
        }

        private void prevBut_Click(object sender, EventArgs e)
        {
            if (current != 1)
            {
                current --;
                FigShow();
            }
            else
            {
                current = 5;
                FigShow();
            }
        }

        private void nextBut_Click(object sender, EventArgs e)
        {
            if (current != 5)
            {
                current++;
                FigShow();
            }
            else
            {
                current = 1;
                FigShow();
            }
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            txtShow.Text = textBox2.Text;
        }

        private void bold_CheckedChanged(object sender, EventArgs e)
        {
            if (bold_Box.Checked == true)
            {
                bold = true;
            }
            else
            {
                bold = false;
            }
            text.ChangeStyle(bold, italic);
            txtShow.Font = new Font(text.Family, text.size, text.Style);
        }

        private void italic_CheckedChanged(object sender, EventArgs e)
        {
            if (italic_Box.Checked == true)
            {
                italic = true;
            }
            else
            {
                italic = false;
            }
            text.ChangeStyle(bold, italic);
            txtShow.Font = new Font(text.Family, text.size, text.Style);
        }

        private void caiyun_Box_CheckedChanged(object sender, EventArgs e)
        {
            string newFamily = "STCaiyun";
            text.ChangeFamily(newFamily);
            txtShow.Font = new Font(text.Family, text.size, text.Style);
        }

        private void snap_Box_CheckedChanged(object sender, EventArgs e)
        {
            string newFamily = "Stencil";
            text.ChangeFamily(newFamily);
            txtShow.Font = new Font(text.Family, text.size, text.Style);
        }

        private void berlin_Box_CheckedChanged(object sender, EventArgs e)
        {
            string newFamily = "Berlin Sans FB";
            text.ChangeFamily(newFamily);
            txtShow.Font = new Font(text.Family, text.size, text.Style);
        }

        private void size_Box_TextChanged(object sender, EventArgs e)
        {
            int size = 12;
            try
            {
                if (size_Box.TextLength > 0)
                {
                    size = int.Parse(size_Box.Text);
                }
            }
            catch
            {
                size = 12;
            }
            if(size>=1 && size <= 32)
            {
                text.ChangeSize(size);
                txtShow.Font = new Font(text.Family, text.size, text.Style);
            }
            else
            {
                size = 12;
                text.ChangeSize(size);
                txtShow.Font = new Font(text.Family, text.size, text.Style);
            }
        }

        private void tleft_CheckedChanged(object sender, EventArgs e)
        {
            int type = 1;
            text.ChangeLabel(txtShow, type);
        }

        private void tmiddle_CheckedChanged(object sender, EventArgs e)
        {
            int type = 2;
            text.ChangeLabel(txtShow,type);
        }

        private void tright_CheckedChanged(object sender, EventArgs e)
        {
            int type = 3;
            text.ChangeLabel(txtShow, type);
        }

        private void bleft_CheckedChanged(object sender, EventArgs e)
        {
            int type = 4;
            text.ChangeLabel(txtShow, type);
        }

        private void bmiddle_CheckedChanged(object sender, EventArgs e)
        {
            int type = 5;
            text.ChangeLabel(txtShow, type);
        }

        private void bright_CheckedChanged(object sender, EventArgs e)
        {
            int type = 6;
            text.ChangeLabel(txtShow, type);
        }
    }
}
