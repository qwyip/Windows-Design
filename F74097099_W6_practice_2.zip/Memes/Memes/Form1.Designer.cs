﻿namespace Memes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pic = new System.Windows.Forms.PictureBox();
            this.prevBut = new System.Windows.Forms.Button();
            this.nextBut = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.caiyun_Box = new System.Windows.Forms.RadioButton();
            this.berlin_Box = new System.Windows.Forms.RadioButton();
            this.snap_Box = new System.Windows.Forms.RadioButton();
            this.bold_Box = new System.Windows.Forms.CheckBox();
            this.italic_Box = new System.Windows.Forms.CheckBox();
            this.textCoor = new System.Windows.Forms.GroupBox();
            this.bright = new System.Windows.Forms.RadioButton();
            this.tright = new System.Windows.Forms.RadioButton();
            this.bmiddle = new System.Windows.Forms.RadioButton();
            this.tmiddle = new System.Windows.Forms.RadioButton();
            this.bleft = new System.Windows.Forms.RadioButton();
            this.tleft = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.size_Box = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.txtShow = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pic)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.textCoor.SuspendLayout();
            this.SuspendLayout();
            // 
            // pic
            // 
            this.pic.Location = new System.Drawing.Point(28, 88);
            this.pic.Name = "pic";
            this.pic.Size = new System.Drawing.Size(476, 319);
            this.pic.TabIndex = 0;
            this.pic.TabStop = false;
            // 
            // prevBut
            // 
            this.prevBut.Location = new System.Drawing.Point(88, 511);
            this.prevBut.Name = "prevBut";
            this.prevBut.Size = new System.Drawing.Size(75, 23);
            this.prevBut.TabIndex = 1;
            this.prevBut.Text = "前一張";
            this.prevBut.UseVisualStyleBackColor = true;
            this.prevBut.Click += new System.EventHandler(this.prevBut_Click);
            // 
            // nextBut
            // 
            this.nextBut.Location = new System.Drawing.Point(372, 511);
            this.nextBut.Name = "nextBut";
            this.nextBut.Size = new System.Drawing.Size(75, 23);
            this.nextBut.TabIndex = 2;
            this.nextBut.Text = "後一張";
            this.nextBut.UseVisualStyleBackColor = true;
            this.nextBut.Click += new System.EventHandler(this.nextBut_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.caiyun_Box);
            this.groupBox1.Controls.Add(this.berlin_Box);
            this.groupBox1.Controls.Add(this.snap_Box);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(559, 76);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(243, 111);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "字體";
            // 
            // caiyun_Box
            // 
            this.caiyun_Box.AutoSize = true;
            this.caiyun_Box.Font = new System.Drawing.Font("STCaiyun", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.caiyun_Box.Location = new System.Drawing.Point(17, 75);
            this.caiyun_Box.Name = "caiyun_Box";
            this.caiyun_Box.Size = new System.Drawing.Size(94, 21);
            this.caiyun_Box.TabIndex = 2;
            this.caiyun_Box.TabStop = true;
            this.caiyun_Box.Text = "STCaiyun";
            this.caiyun_Box.UseVisualStyleBackColor = true;
            this.caiyun_Box.CheckedChanged += new System.EventHandler(this.caiyun_Box_CheckedChanged);
            // 
            // berlin_Box
            // 
            this.berlin_Box.AutoSize = true;
            this.berlin_Box.Font = new System.Drawing.Font("Berlin Sans FB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.berlin_Box.Location = new System.Drawing.Point(131, 38);
            this.berlin_Box.Name = "berlin_Box";
            this.berlin_Box.Size = new System.Drawing.Size(99, 19);
            this.berlin_Box.TabIndex = 1;
            this.berlin_Box.TabStop = true;
            this.berlin_Box.Text = "Berlin Sans FB";
            this.berlin_Box.UseVisualStyleBackColor = true;
            this.berlin_Box.CheckedChanged += new System.EventHandler(this.berlin_Box_CheckedChanged);
            // 
            // snap_Box
            // 
            this.snap_Box.AutoSize = true;
            this.snap_Box.Checked = true;
            this.snap_Box.Font = new System.Drawing.Font("Stencil", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.snap_Box.Location = new System.Drawing.Point(17, 38);
            this.snap_Box.Name = "snap_Box";
            this.snap_Box.Size = new System.Drawing.Size(78, 20);
            this.snap_Box.TabIndex = 0;
            this.snap_Box.TabStop = true;
            this.snap_Box.Text = "Stencil";
            this.snap_Box.UseVisualStyleBackColor = true;
            this.snap_Box.CheckedChanged += new System.EventHandler(this.snap_Box_CheckedChanged);
            // 
            // bold_Box
            // 
            this.bold_Box.AutoSize = true;
            this.bold_Box.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bold_Box.Location = new System.Drawing.Point(576, 205);
            this.bold_Box.Name = "bold_Box";
            this.bold_Box.Size = new System.Drawing.Size(60, 24);
            this.bold_Box.TabIndex = 7;
            this.bold_Box.Text = "粗體";
            this.bold_Box.UseVisualStyleBackColor = true;
            this.bold_Box.CheckedChanged += new System.EventHandler(this.bold_CheckedChanged);
            // 
            // italic_Box
            // 
            this.italic_Box.AutoSize = true;
            this.italic_Box.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.italic_Box.Location = new System.Drawing.Point(690, 205);
            this.italic_Box.Name = "italic_Box";
            this.italic_Box.Size = new System.Drawing.Size(60, 24);
            this.italic_Box.TabIndex = 8;
            this.italic_Box.Text = "斜體";
            this.italic_Box.UseVisualStyleBackColor = true;
            this.italic_Box.CheckedChanged += new System.EventHandler(this.italic_CheckedChanged);
            // 
            // textCoor
            // 
            this.textCoor.Controls.Add(this.bright);
            this.textCoor.Controls.Add(this.tright);
            this.textCoor.Controls.Add(this.bmiddle);
            this.textCoor.Controls.Add(this.tmiddle);
            this.textCoor.Controls.Add(this.bleft);
            this.textCoor.Controls.Add(this.tleft);
            this.textCoor.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textCoor.Location = new System.Drawing.Point(559, 246);
            this.textCoor.Name = "textCoor";
            this.textCoor.Size = new System.Drawing.Size(243, 118);
            this.textCoor.TabIndex = 9;
            this.textCoor.TabStop = false;
            this.textCoor.Text = "位置";
            // 
            // bright
            // 
            this.bright.AutoSize = true;
            this.bright.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bright.Location = new System.Drawing.Point(178, 80);
            this.bright.Name = "bright";
            this.bright.Size = new System.Drawing.Size(59, 24);
            this.bright.TabIndex = 5;
            this.bright.Text = "下右";
            this.bright.UseVisualStyleBackColor = true;
            this.bright.CheckedChanged += new System.EventHandler(this.bright_CheckedChanged);
            // 
            // tright
            // 
            this.tright.AutoSize = true;
            this.tright.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tright.Location = new System.Drawing.Point(178, 39);
            this.tright.Name = "tright";
            this.tright.Size = new System.Drawing.Size(59, 24);
            this.tright.TabIndex = 4;
            this.tright.Text = "上右";
            this.tright.UseVisualStyleBackColor = true;
            this.tright.CheckedChanged += new System.EventHandler(this.tright_CheckedChanged);
            // 
            // bmiddle
            // 
            this.bmiddle.AutoSize = true;
            this.bmiddle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bmiddle.Location = new System.Drawing.Point(98, 80);
            this.bmiddle.Name = "bmiddle";
            this.bmiddle.Size = new System.Drawing.Size(59, 24);
            this.bmiddle.TabIndex = 3;
            this.bmiddle.Text = "下中";
            this.bmiddle.UseVisualStyleBackColor = true;
            this.bmiddle.CheckedChanged += new System.EventHandler(this.bmiddle_CheckedChanged);
            // 
            // tmiddle
            // 
            this.tmiddle.AutoSize = true;
            this.tmiddle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmiddle.Location = new System.Drawing.Point(98, 39);
            this.tmiddle.Name = "tmiddle";
            this.tmiddle.Size = new System.Drawing.Size(59, 24);
            this.tmiddle.TabIndex = 2;
            this.tmiddle.Text = "上中";
            this.tmiddle.UseVisualStyleBackColor = true;
            this.tmiddle.CheckedChanged += new System.EventHandler(this.tmiddle_CheckedChanged);
            // 
            // bleft
            // 
            this.bleft.AutoSize = true;
            this.bleft.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bleft.Location = new System.Drawing.Point(17, 80);
            this.bleft.Name = "bleft";
            this.bleft.Size = new System.Drawing.Size(59, 24);
            this.bleft.TabIndex = 1;
            this.bleft.Text = "下左";
            this.bleft.UseVisualStyleBackColor = true;
            this.bleft.CheckedChanged += new System.EventHandler(this.bleft_CheckedChanged);
            // 
            // tleft
            // 
            this.tleft.AutoSize = true;
            this.tleft.Checked = true;
            this.tleft.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tleft.Location = new System.Drawing.Point(17, 39);
            this.tleft.Name = "tleft";
            this.tleft.Size = new System.Drawing.Size(59, 24);
            this.tleft.TabIndex = 0;
            this.tleft.TabStop = true;
            this.tleft.Text = "上左";
            this.tleft.UseVisualStyleBackColor = true;
            this.tleft.CheckedChanged += new System.EventHandler(this.tleft_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(585, 387);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "字體大小 :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(664, 428);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "文字";
            // 
            // size_Box
            // 
            this.size_Box.Location = new System.Drawing.Point(668, 389);
            this.size_Box.Name = "size_Box";
            this.size_Box.Size = new System.Drawing.Size(95, 20);
            this.size_Box.TabIndex = 12;
            this.size_Box.Text = "12";
            this.size_Box.TextChanged += new System.EventHandler(this.size_Box_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(559, 451);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(257, 88);
            this.textBox2.TabIndex = 13;
            this.textBox2.Text = "Good Morning";
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtShow
            // 
            this.txtShow.Font = new System.Drawing.Font("Stencil", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShow.Location = new System.Drawing.Point(35, 32);
            this.txtShow.Name = "txtShow";
            this.txtShow.Size = new System.Drawing.Size(459, 430);
            this.txtShow.TabIndex = 14;
            this.txtShow.Text = "Good Morning";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 562);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.size_Box);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textCoor);
            this.Controls.Add(this.italic_Box);
            this.Controls.Add(this.bold_Box);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.nextBut);
            this.Controls.Add(this.prevBut);
            this.Controls.Add(this.pic);
            this.Controls.Add(this.txtShow);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pic)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.textCoor.ResumeLayout(false);
            this.textCoor.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pic;
        private System.Windows.Forms.Button prevBut;
        private System.Windows.Forms.Button nextBut;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox bold_Box;
        private System.Windows.Forms.CheckBox italic_Box;
        private System.Windows.Forms.GroupBox textCoor;
        private System.Windows.Forms.RadioButton bright;
        private System.Windows.Forms.RadioButton tright;
        private System.Windows.Forms.RadioButton bmiddle;
        private System.Windows.Forms.RadioButton tmiddle;
        private System.Windows.Forms.RadioButton bleft;
        private System.Windows.Forms.RadioButton tleft;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox size_Box;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label txtShow;
        private System.Windows.Forms.RadioButton snap_Box;
        private System.Windows.Forms.RadioButton berlin_Box;
        private System.Windows.Forms.RadioButton caiyun_Box;
    }
}

