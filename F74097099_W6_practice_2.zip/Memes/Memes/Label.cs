﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Memes
{
    class Label
    {
        public int size;
        public FontFamily Family;
        public FontStyle Style;
        public ContentAlignment Alignment=ContentAlignment.TopLeft;
        public int YLocation = 32;
        public void ChangeLabel(System.Windows.Forms.Label label,int num)
        {
            if(num==1)
                label.TextAlign = ContentAlignment.TopLeft;
            if(num==2)
                label.TextAlign = ContentAlignment.TopCenter;
            if (num == 3)
                label.TextAlign = ContentAlignment.TopRight;
            if (num == 4)
                label.TextAlign = ContentAlignment.BottomLeft;
            if (num == 5)
                label.TextAlign = ContentAlignment.BottomCenter;
            if (num == 6)
                label.TextAlign = ContentAlignment.BottomRight;
        }
       
        public void ChangeFamily(string newFamily)
        {
            if (newFamily.Equals("Berlin Sans FB"))
            {
                this.Family = new FontFamily("Berlin Sans FB");
            }
            if (newFamily.Equals("Stencil"))
            {
                this.Family = new FontFamily("Stencil");
            }
            if (newFamily.Equals("STCaiyun"))
            {
                this.Family = new FontFamily("STCaiyun");
            }

        }
        public void ChangeStyle(bool bold, bool italic)
        {
            if (bold == true && italic==false)
                this.Style = FontStyle.Bold;
            if (bold == false && italic == true)
                this.Style = FontStyle.Italic;
            if (bold == true && italic == true)
                this.Style = FontStyle.Bold | FontStyle.Italic;
            if (bold == false && italic == false)
                this.Style = FontStyle.Regular;
        }

        public void ChangeSize(int newSize)
        {
            this.size = newSize;
        }
    }
}
