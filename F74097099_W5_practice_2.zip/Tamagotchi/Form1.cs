﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tamagotchi
{
    public partial class Form1 : Form
    {
        
        
        public Form1()
        {
            InitializeComponent();        
                      
        }

        Tama tama = new Tama();

        private void button6_Click(object sender, EventArgs e)
        {
            if ((textBox2.Text).Equals(""))
            {
                tama.Name = "Tamagotchi";
            }
            else tama.Name = textBox2.Text;

            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = false;


            tama.Check();
            label8.Text = (tama.money).ToString() + "$";
            label9.Text = (tama.health).ToString() + "%";
            label10.Text = (tama.satisfaction).ToString() + "%";
            label11.Text = (tama.weight).ToString() + "g";
            label12.Text = (tama.emotion).ToString() + "%";
            label14.Text = tama.Name + " was born";

            textBox2.Text = tama.Name;
            textBox2.Enabled = false;

            textBox1.AppendText("You started keeping "+ tama.Name +" \r\n");
            textBox1.AppendText("Day1\r\n");


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tama.money<10)
            {
                textBox1.AppendText("Can't afford to feed.\r\n");
            }
            else
            {
                textBox1.AppendText("Fed " + tama.Name+" \r\n");
                tama.Feed();
            }

            tama.Check();
            label8.Text = (tama.money).ToString() + "$";
            label9.Text = (tama.health).ToString() + "%";
            label10.Text = (tama.satisfaction).ToString() + "%";
            label11.Text = (tama.weight).ToString() + "g";
            label12.Text = (tama.emotion).ToString() + "%";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tama.money < 5)
            {
                textBox1.AppendText("Can't afford to play.\r\n");
            }
            else
            {
                textBox1.AppendText("Played with " + tama.Name +" \r\n");
                tama.Play();
            }

            tama.Check();
            label8.Text = (tama.money).ToString() + "$";
            label9.Text = (tama.health).ToString() + "%";
            label10.Text = (tama.satisfaction).ToString() + "%";
            label11.Text = (tama.weight).ToString() + "g";
            label12.Text = (tama.emotion).ToString() + "%";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (tama.money < 5)
            {
                textBox1.AppendText("Can't afford to clean.\r\n");
            }
            else
            {
                textBox1.AppendText("Cleaned the " + tama.Name +" \r\n");
                tama.Clean();
                
            }

            tama.Check();
            label8.Text = (tama.money).ToString() + "$";
            label9.Text = (tama.health).ToString() + "%";
            label10.Text = (tama.satisfaction).ToString() + "%";
            label11.Text = (tama.weight).ToString() + "g";
            label12.Text = (tama.emotion).ToString() + "%";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if ((label14.Text).Contains("pooped")) //Poop didnt clean
            {
                tama.health -= 30;
            }
            label14.Text = "";
            textBox1.AppendText("\r\nDay");
            textBox1.AppendText(tama.count.ToString()+"\r\n");
            //lay eggs
            if ((tama.weight >= 1000) && (tama.health >= 60)&& tama.rdm.Next(1, 101) <= tama.emotion)
            {
                tama.LayEggs();
                textBox1.AppendText(tama.lay_egg_str + "\r\n");
            }
            tama.EndThisDay();

            //Event
            //poop
            if (tama.IsDirty)
            {
                label14.Text += tama.Name + " pooped\r\n";
                textBox1.AppendText("It pooped\r\n");
            }
            //sick
            if (tama.IsSick)
            {
                label14.Text += tama.Name + " is sick\r\n";
                textBox1.AppendText(tama.Name+"is sick\r\n");
            }
            if ((String.IsNullOrEmpty(label14.Text)))
            {
                label14.Text += tama.Name + " is behaving today ";
                textBox1.AppendText("A day has passed\r\n");
            }
           
            //dead
            if (tama.IsDead)
            {
                label14.Text += tama.Name + " is dead\r\n";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                textBox1.AppendText(tama.Name + " is dead.Game Over.");
                textBox1.Enabled = false;
            }

       
            
            tama.Check();
            label8.Text = (tama.money).ToString() + "$";
            label9.Text = (tama.health).ToString() + "%";
            label10.Text = (tama.satisfaction).ToString() + "%";
            label11.Text = (tama.weight).ToString() + "g";
            label12.Text = (tama.emotion).ToString() + "%";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (tama.money < 20)
            {
                textBox1.AppendText("Can't afford to take it to see doctor.\r\n");
            }
            else
            {
                textBox1.AppendText("Took "+tama.Name+" to the doctor\r\n");
                tama.Doctor();
            }

            tama.Check();
            label8.Text = (tama.money).ToString() + "$";
            label9.Text = (tama.health).ToString() + "%";
            label10.Text = (tama.satisfaction).ToString() + "%";
            label11.Text = (tama.weight).ToString() + "g";
            label12.Text = (tama.emotion).ToString() + "%";
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
