﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tamagotchi
{
    class Tama
    {
        public String Name;
        public int money=500;
        public int health=70;
        public int weight=700;
        public int satisfaction=70;
        public int emotion=50;
        public bool IsDirty;
        public bool IsSick;
        public bool IsDead;
        public int count = 2;
        public string lay_egg_str;
        public Random rdm = new Random();
        
        public void Feed()
        {
            if (IsDirty) health -= 10;  
            money -= 10;
            satisfaction += rdm.Next(0, 21);
            weight += rdm.Next(50, 101);
        }
        public void Play()
        {
            money -= 5;
            health += rdm.Next(0, 20);
            emotion+= rdm.Next(0, 20);
            satisfaction-= rdm.Next(0, 20);
        }
        public void Clean()
        {
            money -= 5;
            IsDirty = false;
        }
        public void Doctor()
        {
            money -= 20;
            health += 30;
            emotion -= 20;
            IsSick = false;
        }
    

        public void LayEggs()
        {
            int income;
            health -= 5;
            income = rdm.Next(15, 26);
            money += income;
            lay_egg_str = Name + " laid an egg,\nand the egg is sold for ";
            lay_egg_str += "$" + income.ToString() + "\n";  
        }

        public void EndThisDay()
        {
            //IsSick
            if (IsSick == false)
            {
                if ((health <= 50) && (emotion <= 50))
                {
                    if (rdm.Next(1, 101) <= (100 - health))
                    {
                        IsSick = true;
                        weight -= 150;
                        emotion -= 20;
                    }
                }
            }
            else
            {
                weight -= 150;
                emotion -= 20;
            }

            //IsDead
            if ((health < 10) && (weight < 1000))
            {
                if (rdm.Next(1, 101) <= (100 - emotion))
                {
                    IsDead = true;
                }
            }
            //Is Dirty
            if (satisfaction >= 50)
                IsDirty = true;

            count += 1;
            satisfaction -= 20;
            if (satisfaction <= 0) weight -= 200;
            if (count > 10) health -= 10;
        }

        public void Check()
        {
            if (health > 100) health = 100;
            if (weight > 4000) weight = 4000;
            if (satisfaction > 100) satisfaction = 100;
            if (emotion > 100) emotion = 100;

            if (health < 0) health = 0;
            if (weight < 600) weight = 600;
            if (satisfaction < 0) satisfaction = 0;
            if (emotion < 0) emotion = 0;


        }
       
    }
}
