﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Substitution_Cipher
{
    public partial class Form1 : Form
    {
        SubstitutionCipher.Class c = new SubstitutionCipher.Class();
        public Form1()
        {
            InitializeComponent();
            label1.Text = c.Alphabet;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label2.Hide();
            textBox1.Hide();
            textBox4.Hide();
            button5.Hide();
            button6.Hide();
            button8.Hide();
            button7.Show();
            label4.Show();
            label5.Show();
            textBox2.Show();
            textBox3.Show();
            textBox2.Clear();
            textBox3.Clear();

            label3.Text = "Encrypt";
            label4.Text = "Enter String:";
            label5.Text = "Encryption Result:";
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = c.Generate(label1.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label3.Text = "Replacement Table";
            label2.Text = "Status";
            textBox1.Show();
            textBox1.Clear();
            textBox2.Hide();
            textBox3.Hide();
            textBox4.Hide();
            label1.Show();
            label2.Show();
            label4.Hide();
            label5.Hide();
            button5.Show();
            button6.Show();
            button7.Hide();
            button8.Hide();


        }

        private void button6_Click(object sender, EventArgs e)
        {
            if ((c.IsValid(textBox1.Text)))
            {
                c.Substitution = textBox1.Text;
                label2.Text = "Proper Replacement Table";
                textBox4.AppendText("New replacement table\n");
                textBox4.AppendText(c.Substitution + "\r\n\r\n");

            }
            else label2.Text = "Improper Replacement Table. Please Enter Again";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox3.Text = c.Encrypt(textBox2.Text);

            textBox4.AppendText("Encrypt\r\n");
            textBox4.AppendText("Plain Text: " + textBox2.Text + "\r\n");
            textBox4.AppendText("\nCipher Text: " + textBox3.Text + "\r\n\r\n");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label2.Hide();
            textBox1.Hide();
            textBox4.Hide();
            button6.Hide();
            button7.Hide();
            button8.Show();
            label4.Show();
            label5.Show();
            textBox2.Show();
            textBox3.Show();
            textBox2.Clear();
            textBox3.Clear();

            label3.Text = "Decrypt";
            label4.Text = "Enter Cipher Text:";
            label5.Text = "Decryption Result:";

           
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox3.Text = c.Decrypt(textBox2.Text);

            textBox4.AppendText("Decrypt\r\n");
            textBox4.AppendText("Cipher Text: " + textBox2.Text + "\r\n");
            textBox4.AppendText("Plain Text: " + textBox3.Text + "\r\n\r\n");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label3.Text = "Historical Record";
            textBox2.Hide();
            textBox3.Hide();
            textBox4.Show();
            button6.Hide();
            button7.Hide();
            button8.Hide();
            label4.Hide();
            label5.Hide();
        }
    }
}
