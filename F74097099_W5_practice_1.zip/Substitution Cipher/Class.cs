﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SubstitutionCipher
{
    class Class
    {
        public String Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

        public String Substitution;

        public string Generate(string str)
        {

            char[] generate_key = str.ToCharArray();
            Random r = new Random();
            int n = generate_key.Length;
            while (n > 1)
            {
                n--;
                int k = r.Next(n + 1);
                char temp = generate_key[k];
                generate_key[k] = generate_key[n];
                generate_key[n] = temp;
            }

            return new string(generate_key);
        }

        public bool IsValid(String Generate)
        {
            if (Generate.Length != 52) return false;

            for (int i = 0; i < Generate.Length; i++)
            {
                for (int j = 0; j < Generate.Length; j++)
                {

                    if (j == i) continue; //Same Coordinate

                    if (Generate[i] == Generate[j]) return false;
                }
            }
            return true;
        }

        public String Encrypt(String text)
        {
            String str = "";
            int index;

            //String.IndexOf(char) 可以找到字元在字串中的 index

            for (int i = 0; i < text.Length; i++)
            {
                if (text[i].Equals(' ')) str += " ";
                else
                {
                    index = Alphabet.IndexOf(text[i]);
                    str += Substitution[index];
                }


            }

            return str;
        }

        public String Decrypt(String text)
        {
            String str = "";
            int index;

            //String.IndexOf(char) 可以找到字元在字串中的 index

            for (int i = 0; i < text.Length; i++)
            {
                if (text[i].Equals(' ')) str += " ";
                else
                {
                    index = Substitution.IndexOf(text[i]);
                    str += Alphabet[index];
                }
            }
            return str;
        }
    }
}




