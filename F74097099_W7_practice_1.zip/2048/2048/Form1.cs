﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2048
{
    public partial class Form1 : Form
    {


        private static Label score;
        private static Label number;
        private static char key = '0';
        public static int[,] area = new int[7, 4];
        private static int[] num = new int[4];
        private static int[] b_num = new int[4];
        static Button[,] now;
        private static double sec = 3.0;
        public static int delete = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            KeyPreview = true;
            scoreLab.Visible = false;
            numLab.Visible = false;
            countLab.Visible = false;
            labCount.Visible = false;
            labCurr.Visible = false;
            labScore.Visible = false;
        }

        private void simButt_Click(object sender, EventArgs e)
        {
            normButt.Visible = false;
            simButt.Visible = false;
            scoreLab.Visible = true;
            numLab.Visible = true;
            labCurr.Visible = true;
            labScore.Visible = true;
            score = labScore;
            score.Text = 0.ToString();
            number = labCurr;
            int ranNum = random();
            number.Text = ranNum.ToString();
            array_zero();
        }

        private void normButt_Click(object sender, EventArgs e)
        {
            normButt.Visible = false;
            simButt.Visible = false;
            scoreLab.Visible = true;
            numLab.Visible = true;
            countLab.Visible = true;
            labCount.Visible = true;
            labCurr.Visible = true;
            labScore.Visible = true;
            score = labScore;
            score.Text = 0.ToString();
            number = labCurr;
            int ranNum = random();
            number.Text = ranNum.ToString();
            array_zero();
            timer1.Enabled = true;
        }

        public static int random()
        {
            int num = 0;
            Random rd = new Random();
            int temp = rd.Next(3);
            if (temp == 0)
                num = 2;
            if (temp == 1)
                num = 4;
            if (temp == 2)
                num =8;
            return num;
        }
        public int start()
        {
            if (key == 'q') combine(0);
            if (key == 'w') combine(1);
            if (key == 'e') combine(2);
            if (key == 'r') combine(3);
            while (true)
            {
                delete = 0;
                del();
                combine(5); //Same Number
                if (delete == 0)
                {
                    break;
                }
            }
            int temp = end();
            if (temp == 0) return 0;
            if (now != null) clear();
            new_button();
            for (int k = 0; k < 4; k++)
            {
                b_num[k] = num[k];
            }
            int n_num = random();
            number.Text = n_num.ToString();

            if (countLab.Visible == true)
            {
                sec = 3.0;
            }
            return 1;
        }
        public static void combine(int row)
        {
            if (row != 5)
            {
                if (num[row] > 0)
                {
                    if (int.Parse(number.Text) == area[num[row] - 1, row])
                    {
                        area[num[row] - 1, row] = area[num[row] - 1, row] * 2;
                    }
                    else
                    {
                        area[num[row], row] = int.Parse(number.Text);
                        num[row]++;
                        return;
                    }
                    while (true)
                    {
                        int enter = 0;
                        if (num[row] >= 2)
                        {
                            if (area[num[row] - 1, row] == area[num[row] - 2, row])
                            {
                                enter = 1;
                                area[num[row] - 2, row] = area[num[row] - 2, row] * 2;
                                area[num[row] - 1, row] = 0;
                                num[row]--;
                            }
                        }
                        else
                            break;
                        if (enter == 0)
                            break;
                    }
                }
                else
                {
                    area[num[row], row] = int.Parse(number.Text);
                    num[row]++;
                }
            }
            else
            {
                for (int i = 0; i < 4; i++)
                {
                    int level = num[i];
                    while (true)
                    {
                        int enter = 0;
                        if (level >= 2)
                        {
                            if (area[level - 1, i] == area[level - 2, i])
                            {
                                enter = 1;
                                area[level - 2, i] = area[level - 2, i] * 2;
                                area[level - 1, i] = 0;
                                num[i]--;
                                level--;
                                for (int j = level; j < num[i]; j++)
                                {
                                    area[j, i] = area[j + 1, i];
                                }
                            }
                        }
                        else
                            break;
                        if (enter == 0)
                            level--;
                        else level++;
                    }
                }
            }
            return;
        }
        
        public static void del()
        {
            int level = 0;
            while (true)
            {
                if (area[level, 0] == area[level, 1] && area[level, 1] == area[level, 2] && area[level, 2] == area[level, 3] && area[level, 0] != 0)
                {
                    delete = 1;
                    score.Text = (int.Parse(score.Text) + area[level, 0] * area[level, 0]).ToString();
                    for (int k = 0; k < 4; k++)
                    {
                        for (int j = level; j < num[k]; j++)
                        {
                            area[j, k] = area[j + 1, k];
                        }
                        num[k]--;
                    }
                }
                else level++;
                if (level > 5) break;
            }
            return;
        }
        public static int end()
        {
            int temp = 0;
            for (int k = 0; k < 4; k++)
            {
                if (num[k] >= 6)
                {
                    temp = 1;
                }
            }
            if (temp == 1)
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        public void clear()
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < b_num[i]; j++)
                {
                    Controls.Remove(now[j, i]);
                }
            }
        }
        public void new_button()
        {
            now = new Button[6, 4];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < num[i]; j++)
                {
                    now[j, i] = new Button();
                    now[j, i].SetBounds(30 + 60 * i, 300 - 60 * j, 50, 50);
                    Controls.Add(now[j, i]);
                    now[j, i].Text = area[j, i].ToString();
                }
            }
        }
        public static void array_zero()
        {
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    area[i, j] = 0;
                }
            }
            for (int i = 0; i < 4; i++)
            {
                num[i] = 0;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            labCount.Text = (sec -= 0.1).ToString("#.0");
            if (sec <= 0)
            {
                key = 'w';
                start();
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            int endgame = 1;
            if (countLab.Visible == false)
            {
                if (e.KeyValue == 65 || e.KeyValue == 97) number.Text = 2.ToString();
                if (e.KeyValue == 83 || e.KeyValue == 97) number.Text = 4.ToString();
                if (e.KeyValue == 68 || e.KeyValue == 97) number.Text = 8.ToString();
            }
            if (e.KeyValue == 81 || e.KeyValue == 113)
            {
                key = 'q';
                endgame = start();
            }
            if (e.KeyValue == 87 || e.KeyValue == 119)
            {
                key = 'w';
                endgame =start();
            }
            if (e.KeyValue == 69 || e.KeyValue == 101)
            {
                key = 'e';
                endgame = start();
            }
            if (e.KeyValue == 82 || e.KeyValue == 114)
            {
                key = 'r';
                endgame = start();
            }
            if (endgame == 0)
            {
                if (countLab.Visible == true) timer1.Stop();
                MessageBox.Show("遊戲結束!!!\r\n你的分數:" + score.Text, "", MessageBoxButtons.OK);
            }
        }
    }
}
