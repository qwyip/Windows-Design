﻿namespace _2048
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.simButt = new System.Windows.Forms.Button();
            this.normButt = new System.Windows.Forms.Button();
            this.scoreLab = new System.Windows.Forms.Label();
            this.numLab = new System.Windows.Forms.Label();
            this.countLab = new System.Windows.Forms.Label();
            this.labScore = new System.Windows.Forms.Label();
            this.labCurr = new System.Windows.Forms.Label();
            this.labCount = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // simButt
            // 
            this.simButt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simButt.Location = new System.Drawing.Point(275, 129);
            this.simButt.Name = "simButt";
            this.simButt.Size = new System.Drawing.Size(112, 44);
            this.simButt.TabIndex = 0;
            this.simButt.Text = "Simple";
            this.simButt.UseVisualStyleBackColor = true;
            this.simButt.Click += new System.EventHandler(this.simButt_Click);
            // 
            // normButt
            // 
            this.normButt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.normButt.Location = new System.Drawing.Point(275, 245);
            this.normButt.Name = "normButt";
            this.normButt.Size = new System.Drawing.Size(112, 44);
            this.normButt.TabIndex = 1;
            this.normButt.Text = "Normal";
            this.normButt.UseVisualStyleBackColor = true;
            this.normButt.Click += new System.EventHandler(this.normButt_Click);
            // 
            // scoreLab
            // 
            this.scoreLab.AutoSize = true;
            this.scoreLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreLab.Location = new System.Drawing.Point(474, 50);
            this.scoreLab.Name = "scoreLab";
            this.scoreLab.Size = new System.Drawing.Size(84, 16);
            this.scoreLab.TabIndex = 2;
            this.scoreLab.Text = "Your Score : ";
            // 
            // numLab
            // 
            this.numLab.AutoSize = true;
            this.numLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numLab.Location = new System.Drawing.Point(474, 83);
            this.numLab.Name = "numLab";
            this.numLab.Size = new System.Drawing.Size(110, 16);
            this.numLab.TabIndex = 3;
            this.numLab.Text = "Current Number : ";
            // 
            // countLab
            // 
            this.countLab.AutoSize = true;
            this.countLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.countLab.Location = new System.Drawing.Point(474, 117);
            this.countLab.Name = "countLab";
            this.countLab.Size = new System.Drawing.Size(83, 16);
            this.countLab.TabIndex = 4;
            this.countLab.Text = "Countdown : ";
            // 
            // labScore
            // 
            this.labScore.AutoSize = true;
            this.labScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labScore.Location = new System.Drawing.Point(555, 50);
            this.labScore.Name = "labScore";
            this.labScore.Size = new System.Drawing.Size(45, 16);
            this.labScore.TabIndex = 5;
            this.labScore.Text = "label2";
            // 
            // labCurr
            // 
            this.labCurr.AutoSize = true;
            this.labCurr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labCurr.Location = new System.Drawing.Point(581, 83);
            this.labCurr.Name = "labCurr";
            this.labCurr.Size = new System.Drawing.Size(45, 16);
            this.labCurr.TabIndex = 6;
            this.labCurr.Text = "label1";
            // 
            // labCount
            // 
            this.labCount.AutoSize = true;
            this.labCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labCount.Location = new System.Drawing.Point(555, 117);
            this.labCount.Name = "labCount";
            this.labCount.Size = new System.Drawing.Size(45, 16);
            this.labCount.TabIndex = 7;
            this.labCount.Text = "label1";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 450);
            this.Controls.Add(this.labCount);
            this.Controls.Add(this.labCurr);
            this.Controls.Add(this.labScore);
            this.Controls.Add(this.countLab);
            this.Controls.Add(this.numLab);
            this.Controls.Add(this.scoreLab);
            this.Controls.Add(this.normButt);
            this.Controls.Add(this.simButt);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button simButt;
        private System.Windows.Forms.Button normButt;
        private System.Windows.Forms.Label scoreLab;
        private System.Windows.Forms.Label numLab;
        private System.Windows.Forms.Label countLab;
        private System.Windows.Forms.Label labScore;
        private System.Windows.Forms.Label labCurr;
        private System.Windows.Forms.Label labCount;
        private System.Windows.Forms.Timer timer1;
    }
}

