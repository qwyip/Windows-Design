﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_4_P1
{
    class Program
    {
        static void Main(string[] args)
        {
            int money1, money2;
            try
            {
                Console.Write("Player 1's initial money:");
                money1 = int.Parse(Console.ReadLine());
                Console.Write("Player 2's initial money:");
                money2 = int.Parse(Console.ReadLine());
                Console.WriteLine("-------------------------------------------------------");
                while (money1 > 0 && money2 > 0) // Make sure both player have enough money
                {
                    int p1_Aceis11 = 0, p2_Aceis11 = 0;
                    int pass = 0;
                    int bet1 = 0;
                    int bet2 = 0;
                    int point1 = 0;
                    int point2 = 0;
                    int p1AceNum = 0;
                    int p2AceNum = 0;
                    int cardNum1 = 2;
                    int cardNum2 = 2;
                    String[] type = new string[] { "Spade", "Heart", "Diamond", "Club" };
                    int[,] pokerNum = new int[4, 13];
                    for (int i = 0; i < 4; i++)
                    {
                        for (int j = 0; j < 13; j++)
                        {
                            pokerNum[i, j] = 0;
                        }
                    }
                    int playerFlower = 0, playerNum = 0;
                    int[] player1_Flower = new int[30];
                    int[] player1_Num = new int[30];
                    int[] player2_Flower = new int[30];
                    int[] player2_Num = new int[30];
                    Random rd = new Random();

                    for (int n = 1; n <= 2; n++) //Player 1 draw 2 initial card
                    {
                        playerFlower = rd.Next(1, 5);
                        playerNum = rd.Next(1, 14);
                        while (true)
                        {
                            if (pokerNum[playerFlower - 1, playerNum - 1] == 0) //Havent been used
                            {
                                pokerNum[playerFlower - 1, playerNum - 1] = 1;
                                if (playerNum == 1) //If Ace
                                {
                                    p1AceNum++; //Number of Ace ++
                                }
                                player1_Flower[n] = playerFlower;
                                player1_Num[n] = playerNum;
                                break;
                            }
                            else //Exist, Card been used
                            {
                                playerFlower = rd.Next(1, 5);
                                playerNum = rd.Next(1, 14);
                            }
                        }
                    }
                    for (int n = 1; n <= 2; n++) //Player 2 draw 2 initial card
                    {
                        playerFlower = rd.Next(1, 5);
                        playerNum = rd.Next(1, 14);
                        while (true)
                        {
                            if (pokerNum[playerFlower - 1, playerNum - 1] == 0) //Card havent been used
                            {
                                pokerNum[playerFlower - 1, playerNum - 1] = 1;
                                if (playerNum == 1) //If Ace
                                {
                                    p2AceNum++;
                                }
                                player2_Flower[n] = playerFlower;
                                player2_Num[n] = playerNum;
                                break;
                            }
                            else
                            {
                                playerFlower = rd.Next(1, 5);
                                playerNum = rd.Next(1, 14);
                            }
                        }
                    }
                    Console.WriteLine("Player 1's cards:" + "{0} {1}" + "," + "{2} {3}", type[player1_Flower[1] - 1], player1_Num[1], type[player1_Flower[2] - 1], player1_Num[2]);

                    for (int n = 1; n <= cardNum1; n++)
                    {
                        if (player1_Num[n] == 1 && p1AceNum == 2) //Have 2 Ace in initial
                        {
                            p1_Aceis11 = 1;
                            point1 = 12;
                        }
                        else if (player1_Num[n] == 1) //Have only one Ace
                        {
                            p1_Aceis11 = 1;
                            point1 += 11;
                        }
                        else if (player1_Num[n] == 11 || player1_Num[n] == 12 || player1_Num[n] == 13) // J,Q,K Consider 10 points
                        {
                            point1 += 10;
                        }
                        else
                        {
                            point1 += player1_Num[n];
                        }
                    }
                    Console.WriteLine("Player 1's current points:{0}", point1);
                    Console.WriteLine("Player 1's current money:{0}", money1);
                    Console.Write("Please enter the amount of bet:");
                    bet1 = int.Parse(Console.ReadLine());
                    while (true)
                    {
                        if (bet1 > money1) //Not enough money
                        {
                            Console.WriteLine("Money is not enough, please enter again!");
                            bet1 = int.Parse(Console.ReadLine());
                            continue;
                        }
                        else if (bet1 == 0) // Enter bet 0
                        {
                            Console.WriteLine("Money should not be 0, please enter again!");
                            Console.Write("Please enter the amount of bet:");
                            bet1 = int.Parse(Console.ReadLine());
                            continue;
                        }
                        else
                        {
                            break;
                        }
                    }
                    Console.WriteLine();
                    Console.WriteLine("Player 2's cards:" + "{0} {1}" + "," + "{2} {3}", type[player2_Flower[1] - 1], player2_Num[1], type[player2_Flower[2] - 1], player2_Num[2]);

                    for (int n = 1; n <= cardNum1; n++)
                    {
                        if (player2_Num[n] == 1 && p2AceNum == 2)
                        {
                            p2_Aceis11 = 1;
                            point2 = 12;
                        }
                        else if (player2_Num[n] == 1)
                        {
                            p2_Aceis11 = 1;
                            point2 += 11;
                        }
                        else if (player2_Num[n] == 11 || player2_Num[n] == 12 || player2_Num[n] == 13)
                        {
                            point2 += 10;
                        }
                        else
                        {
                            point2 += player2_Num[n];
                        }
                    }
                    Console.WriteLine("Player 2's current points:{0}", point2);
                    Console.WriteLine("Player 2's current money:{0}", money2);
                    Console.Write("Please enter the amount of bet:");
                    bet2 = int.Parse(Console.ReadLine());
                    while (true)
                    {
                        if (bet2 > money2) //Not enough money
                        {
                            Console.WriteLine("Money is not enough, please enter again!");
                            bet2 = int.Parse(Console.ReadLine());
                            continue;
                        }
                        else if (bet2 == 0) //Enter bet 0
                        {
                            Console.WriteLine("Money should not be 0, please enter again!");
                            Console.Write("Please enter the amount of bet:");
                            bet2 = int.Parse(Console.ReadLine());
                            continue;
                        }
                        else
                        {
                            break;
                        }
                    }
                    Console.WriteLine();
                    int p1_lose = 0;
                    int p1_AceTo1 = 0;
                    while (true)
                    {
                        string key = "";
                        Console.WriteLine("Player 1's turn (Enter 1 to pick a card and enter P to stop):");
                        key = Console.ReadLine();
                        if (key == "1") //Draw 1 new card
                        {
                            cardNum1++; //Hand Card ++
                            playerFlower = rd.Next(1, 5);
                            playerNum = rd.Next(1, 14);
                            while (true)
                            {
                                if (pokerNum[playerFlower - 1, playerNum - 1] == 0) //Card havent been used
                                {
                                    pokerNum[playerFlower - 1, playerNum - 1] = 1;
                                    if (playerNum == 1) //If Ace
                                    {
                                        p1AceNum++;
                                    }
                                    player1_Flower[cardNum1] = playerFlower;
                                    player1_Num[cardNum1] = playerNum;
                                    break;
                                }
                                else
                                {
                                    playerFlower = rd.Next(1, 5);
                                    playerNum = rd.Next(1, 14);
                                }
                            }
                            Console.Write("Player 1's cards:");
                            for (int n = 1; n <= cardNum1; n++)
                            {
                                if (n != cardNum1)
                                {
                                    Console.Write("{0} {1},", type[player1_Flower[n] - 1], player1_Num[n]);
                                }
                                else //Last Card need space
                                {
                                    Console.WriteLine("{0} {1}", type[player1_Flower[n] - 1], player1_Num[n]);
                                }
                            }
                            if (player1_Num[cardNum1] == 1 && p1AceNum >= 2) //Have 2 Ace
                            {
                                point1 += 1;
                            }
                            else if (player1_Num[cardNum1] == 1 && point1 > 10 && p1_AceTo1 == 0) //Points larger than 10 , Ace be 1
                            {
                                p1_AceTo1 = 1;
                                point1 += 1;
                            }
                            else if (player1_Num[cardNum1] == 1 && point1 <= 10)//Points lower than 10 , Ace be 11
                            {
                                p1_AceTo1 = 1;
                                point1 += 11;
                            }
                            else if (point1 + player1_Num[cardNum1] > 21 && p1AceNum >= 1 && p1_AceTo1 == 0 && p1_Aceis11 == 1) //Need to change Ace from 11 to 1
                            {
                                p1_AceTo1 = 1;
                                if (player1_Num[cardNum1] == 11 || player1_Num[cardNum1] == 12 || player1_Num[cardNum1] == 13) ; //Ignore JQK
                                     //Example: If 8+2+1=11,Draw 13, no need to change Ace Value
                                     //If 8+4+A=13, It already minus 10 before
                                else
                                {
                                    point1 += player1_Num[cardNum1] - 10;
                                }
                            }
                            else if (player1_Num[cardNum1] == 11 || player1_Num[cardNum1] == 12 || player1_Num[cardNum1] == 13)
                            {
                                point1 += 10;
                            }
                            else
                            {
                                point1 += player1_Num[cardNum1];
                            }
                            Console.WriteLine("Players 1's current points:{0}", point1);
                            if (point1 > 21)
                            {
                                Console.WriteLine("Player 1 lost, and player 2 won!\n");
                                p1_lose = 1;
                                pass = 1;
                                Console.WriteLine("Player 2 won and gets ${0}", bet1);
                                money2 += bet1;
                                money1 -= bet1;
                                break;
                            }
                            else
                            {
                                continue;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Player 1 skips with current points:{0}", point1);
                            break;
                        }
                    }
                    int p2_AceTo1 = 0;
                    while (p1_lose == 0)
                    {
                        string key = "";
                        Console.WriteLine("Player 2's turn (Enter 1 to pick a card and enter P to stop):");
                        key = Console.ReadLine();
                        if (key == "1")
                        {
                            cardNum2++;
                            playerFlower = rd.Next(1, 5);
                            playerNum = rd.Next(1, 14);
                            while (true)
                            {
                                if (pokerNum[playerFlower - 1, playerNum - 1] == 0)
                                {
                                    pokerNum[playerFlower - 1, playerNum - 1] = 1;
                                    if (playerNum == 1)
                                    {
                                        p2AceNum++;
                                    }
                                    player2_Flower[cardNum2] = playerFlower;
                                    player2_Num[cardNum2] = playerNum;
                                    break;
                                }
                                else
                                {
                                    playerFlower = rd.Next(1, 5);
                                    playerNum = rd.Next(1, 14);
                                }
                            }
                            Console.Write("Player 2's cards:");
                            for (int n = 1; n <= cardNum2; n++)
                            {
                                if (n != cardNum2)
                                {
                                    Console.Write("{0} {1},", type[player2_Flower[n] - 1], player2_Num[n]);
                                }
                                else
                                {
                                    Console.WriteLine("{0} {1}", type[player2_Flower[n] - 1], player2_Num[n]);
                                }
                            }
                            if (player2_Num[cardNum2] == 1 && p2AceNum >= 2)
                            {
                                point2 += 1;
                            }
                            else if (player2_Num[cardNum2] == 1 && point2 > 10 && p2_AceTo1 == 0)
                            {
                                p2_AceTo1 = 1;
                                point2 += 1;
                            }
                            else if (player2_Num[cardNum2] == 1 && point2 <= 10)
                            {
                                p2_Aceis11 = 1;
                                point2 += 11;
                            }

                            else if (point2 + player2_Num[cardNum2] > 21 && p2AceNum >= 1 && p2_AceTo1 == 0 && p2_Aceis11 == 1)
                            {
                                p2_AceTo1 = 1;
                                if (player2_Num[cardNum2] == 11 || player2_Num[cardNum2] == 12 || player2_Num[cardNum2] == 13) ;
                                else
                                {
                                    point2 += player2_Num[cardNum2] - 10;
                                }
                            }
                            else if (player2_Num[cardNum2] == 11 || player2_Num[cardNum2] == 12 || player2_Num[cardNum2] == 13)
                            {
                                point2 += 10;
                            }
                            else
                            {
                                point2 += player2_Num[cardNum2];
                            }
                            Console.WriteLine("Player 2's current points:{0}", point2);
                            if (point2 > 21)
                            {
                                Console.WriteLine("Player 2 lost, player 1 won!\n");
                                pass = 1;
                                Console.WriteLine("Player 1 won and gets ${0}", bet2);
                                money1 += bet2;
                                money2 -= bet2;
                                break;
                            }
                            else
                            {
                                continue;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Player 2 skipped with current points:{0}", point2);
                            break;
                        }
                    }
                    if (pass == 1)
                    {
                        Console.WriteLine("-------------------------------------------------------");
                        continue;
                    }
                    if (point1 > point2)
                    {
                        Console.WriteLine("Player 1 won and gets ${0}", bet2);
                        money1 += bet2;
                        money2 -= bet2;
                    }
                    else if (point1 < point2)
                    {
                        Console.WriteLine("Player 2 won and gets ${0}", bet1);
                        money2 += bet1;
                        money1 -= bet1;
                    }
                    else
                    {
                        Console.WriteLine("It's a tie! Both players get their money back");
                    }
                    Console.WriteLine("-----------------" +
                        "--------------------------------------");

                }
                Console.ReadKey();
                return;
            }
            catch (FormatException)
            {
                Console.WriteLine("Please enter in the correct format");
                Console.ReadKey();
                return;
            }
            Console.ReadKey();
        }
    }
}
