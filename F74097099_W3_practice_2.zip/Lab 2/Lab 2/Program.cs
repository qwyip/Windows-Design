﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("地圖大小(1-10):");
            try
            {
                int n = int.Parse(Console.ReadLine());
                if (n < 1 || n > 10)
                {
                    Console.Write("超出範圍");
                    Console.ReadKey();
                }
                else
                {
                    Console.Write("地雷數量(1-10):");
                    int bombNum = int.Parse(Console.ReadLine());
                    if (bombNum < 1 || bombNum > 10)
                    {
                        Console.Write("超出範圍");
                        Console.ReadKey();
                    }
                    else
                    {
                        try
                        {
                            int[] bombX = new int[n];
                            int[] bombY = new int[n];
                            for (int i = 0; i < bombNum; i++)
                            {
                                Console.Write("第 {0} 個地雷的位置(以空白區隔):", i);
                                string[] tokens = Console.ReadLine().Split();
                                bombY[i] = int.Parse(tokens[0]);
                                bombX[i] = int.Parse(tokens[1]);
                                if (bombX[i]>=0 && bombY[i] >= 0 && bombX[i] < n && bombY[i] < n)
                                {
                                    continue;
                                }
                                else
                                {
                                    Console.Write("地雷位置超出範圍");
                                    Console.ReadKey();
                                    return;
                                }
                            }
                            char[,] map = new char[n, n];
                            for (int i = 0; i < n; i++)
                            {
                                for (int j = 0; j < n; j++)
                                {
                                    map[i, j] = '0';
                                }
                            }
                            for (int i = 0; i < bombNum; i++)
                            {
                                map[bombX[i], bombY[i]] = 'X';
                                if (bombX[i] != 0) // Not at Top
                                {
                                    if (map[bombX[i] - 1, bombY[i]] != 'X') // Not Bomb Then Change
                                    {
                                        map[bombX[i] - 1, bombY[i]]++; //Top ++
                                    }
                                }
                                if (bombX[i] != n - 1) // Not at Bottom
                                {
                                    if (map[bombX[i] + 1, bombY[i]] != 'X') // Not Bomb Then Change
                                    {
                                        map[bombX[i] + 1, bombY[i]]++; //Bottom ++
                                    }
                                }
                                if (bombY[i] != 0) // Not at Left
                                {
                                    if (map[bombX[i], bombY[i] - 1] != 'X') // Not Bomb Then Change
                                    {
                                        map[bombX[i], bombY[i] - 1]++; //Left ++
                                    }
                                }
                                if (bombY[i] != n - 1) // Not at Right
                                {
                                    if (map[bombX[i], bombY[i] + 1] != 'X') // Not Bomb Then Change
                                    {
                                        map[bombX[i], bombY[i] + 1]++; //Left ++
                                    }
                                }
                                if (bombX[i] != 0 && bombY[i] != 0) // Not Left Top
                                {
                                    if (map[bombX[i] - 1, bombY[i] - 1] != 'X') // Not Bomb Then Change
                                    {
                                        map[bombX[i] - 1, bombY[i] - 1]++; //Left Top++
                                    }
                                }
                                if (bombX[i] != n - 1 && bombY[i] != n - 1) // Not Right Bottom
                                {
                                    if (map[bombX[i] + 1, bombY[i] + 1] != 'X') // Not Bomb Then Change
                                    {
                                        map[bombX[i] + 1, bombY[i] + 1]++; //Right Bottom++
                                    }
                                }
                                if (bombX[i] != 0 && bombY[i] != n - 1) // Not Right Top
                                {
                                    if (map[bombX[i] - 1, bombY[i] + 1] != 'X') // Not Bomb Then Change
                                    {
                                        map[bombX[i] - 1, bombY[i] + 1]++; //Right Top++
                                    }
                                }
                                if (bombX[i] != n - 1 && bombY[i] != 0) // Not Left Bottom
                                {
                                    if (map[bombX[i] + 1, bombY[i] - 1] != 'X') // Not Bomb Then Change
                                    {
                                        map[bombX[i] + 1, bombY[i] - 1]++; //Right Bottom++
                                    }
                                }
                            }
                            Console.WriteLine("---");
                            for (int i = 0; i < n; i++)
                            {
                                for (int j = 0; j < n; j++)
                                {
                                    Console.Write("{0}", map[i, j]);
                                }
                                Console.WriteLine();
                            }
                            Console.ReadKey();
                        }
                        catch (FormatException ex)
                        {
                            Console.Write("請輸入兩個以空白區隔的整數");
                            Console.ReadKey();
                        }
                        catch (IndexOutOfRangeException ex)
                        {
                            Console.Write("請輸入兩個以空白區隔的整數");
                            Console.ReadKey();
                        }
                    }
                }
            }
            catch (FormatException ex)
            {
                Console.Write("請輸入範圍內的整數");
                Console.ReadKey();
            }
        }
    }
}
