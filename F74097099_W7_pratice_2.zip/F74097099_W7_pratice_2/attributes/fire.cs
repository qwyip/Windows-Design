﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace attributes
{
    class fire : attributes
    {
        public int speed = 20;
   
        public void color(System.Windows.Forms.Button b)
        {
            b.BackColor = Color.Red;
        }
    }
}
