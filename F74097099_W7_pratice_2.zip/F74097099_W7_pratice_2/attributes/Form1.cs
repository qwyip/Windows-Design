﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace attributes
{
    public partial class Form1 : Form
    {
        public static int atb;
       
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "Choose Initial Attribute:";
            water.Text = "Water";
            fire.Text = "Fire";
            wood.Text = "Wood";
            button1.Text = "Start";
                }

        private void water_CheckedChanged(object sender, EventArgs e)
        {
           atb = 1;
        }

        private void fire_CheckedChanged(object sender, EventArgs e)
        {
           atb = 2;
        }

        private void wood_CheckedChanged(object sender, EventArgs e)
        {
            atb =3;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            Form2 f2 = new Form2();
            this.Hide();
            f2.ShowDialog();
            this.Close();
        }
    }
}
