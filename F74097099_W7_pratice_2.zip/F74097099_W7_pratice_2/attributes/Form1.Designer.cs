﻿namespace attributes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.water = new System.Windows.Forms.RadioButton();
            this.fire = new System.Windows.Forms.RadioButton();
            this.wood = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(74, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // water
            // 
            this.water.AutoSize = true;
            this.water.Location = new System.Drawing.Point(109, 132);
            this.water.Name = "water";
            this.water.Size = new System.Drawing.Size(126, 24);
            this.water.TabIndex = 1;
            this.water.TabStop = true;
            this.water.Text = "radioButton1";
            this.water.UseVisualStyleBackColor = true;
            this.water.CheckedChanged += new System.EventHandler(this.water_CheckedChanged);
            // 
            // fire
            // 
            this.fire.AutoSize = true;
            this.fire.Location = new System.Drawing.Point(109, 163);
            this.fire.Name = "fire";
            this.fire.Size = new System.Drawing.Size(126, 24);
            this.fire.TabIndex = 2;
            this.fire.TabStop = true;
            this.fire.Text = "radioButton2";
            this.fire.UseVisualStyleBackColor = true;
            this.fire.CheckedChanged += new System.EventHandler(this.fire_CheckedChanged);
            // 
            // wood
            // 
            this.wood.AutoSize = true;
            this.wood.Location = new System.Drawing.Point(109, 194);
            this.wood.Name = "wood";
            this.wood.Size = new System.Drawing.Size(126, 24);
            this.wood.TabIndex = 3;
            this.wood.TabStop = true;
            this.wood.Text = "radioButton3";
            this.wood.UseVisualStyleBackColor = true;
            this.wood.CheckedChanged += new System.EventHandler(this.wood_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(131, 240);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 46);
            this.button1.TabIndex = 4;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(456, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.wood);
            this.Controls.Add(this.fire);
            this.Controls.Add(this.water);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton water;
        private System.Windows.Forms.RadioButton fire;
        private System.Windows.Forms.RadioButton wood;
        private System.Windows.Forms.Button button1;
    }
}

