﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading.Tasks;

namespace attributes
{
    class attributes
    {
        public int ply_atb;
        public int blt_atb;
        public int[] enm_atb = new int[5];
        static Random rdmObj = new Random();
        
        public string s_atb(int ply_atb)
        {
            switch (ply_atb)
            {
                case 1: return "Water";
                case 2: return "Fire";
                case 3: return "Wood";              
            }

            return "";
        }
        public void set_enm_atb(int i)
        {          
                int rdmNum = rdmObj.Next(1, 4);
                //water1 fire2 wood3
                enm_atb[i] = rdmNum;        
        }

        public void move(System.Windows.Forms.Button b,int s)
        {
            b.Top += s;
        }

        public void shoot(System.Windows.Forms.Button b, int s)
        {
            b.Top -= s;
        }
    }
}
