﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace attributes
{
    class water : attributes
    {
        public int speed = 10;    
        
        
        public void color(System.Windows.Forms.Button b)
        {
            b.BackColor = Color.Blue;
        }
    }
}
