﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace attributes
{
    class wood :attributes
    {
        public int speed = 30;
       
        public void color(System.Windows.Forms.Button b)
        {
            b.BackColor = Color.Green;
        }
    }
}
