﻿namespace attributes
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.player = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.atb_lbl = new System.Windows.Forms.Label();
            this.scr_lbl = new System.Windows.Forms.Label();
            this.cd_lbl = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // player
            // 
            this.player.Location = new System.Drawing.Point(101, 192);
            this.player.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.player.Name = "player";
            this.player.Size = new System.Drawing.Size(40, 40);
            this.player.TabIndex = 0;
            this.player.Text = "button1";
            this.player.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel
            // 
            this.panel.Controls.Add(this.player);
            this.panel.Location = new System.Drawing.Point(24, 67);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(395, 511);
            this.panel.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(486, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Current Attribute:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(486, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Score:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(490, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "CountDown:";
            // 
            // atb_lbl
            // 
            this.atb_lbl.AutoSize = true;
            this.atb_lbl.Location = new System.Drawing.Point(612, 103);
            this.atb_lbl.Name = "atb_lbl";
            this.atb_lbl.Size = new System.Drawing.Size(51, 20);
            this.atb_lbl.TabIndex = 9;
            this.atb_lbl.Text = "label4";
            // 
            // scr_lbl
            // 
            this.scr_lbl.AutoSize = true;
            this.scr_lbl.Location = new System.Drawing.Point(548, 142);
            this.scr_lbl.Name = "scr_lbl";
            this.scr_lbl.Size = new System.Drawing.Size(51, 20);
            this.scr_lbl.TabIndex = 10;
            this.scr_lbl.Text = "label5";
            // 
            // cd_lbl
            // 
            this.cd_lbl.AutoSize = true;
            this.cd_lbl.Location = new System.Drawing.Point(593, 185);
            this.cd_lbl.Name = "cd_lbl";
            this.cd_lbl.Size = new System.Drawing.Size(42, 20);
            this.cd_lbl.TabIndex = 11;
            this.cd_lbl.Text = "label";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(758, 708);
            this.Controls.Add(this.cd_lbl);
            this.Controls.Add(this.scr_lbl);
            this.Controls.Add(this.atb_lbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form2_KeyDown);
            this.panel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button player;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label atb_lbl;
        private System.Windows.Forms.Label scr_lbl;
        private System.Windows.Forms.Label cd_lbl;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
    }
}