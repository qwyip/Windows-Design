﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace attributes
{
    public partial class Form2 : Form
    {
        attributes p = new attributes();
        water wt = new water();
        fire fr = new fire();
        wood wd = new wood();
        Button[] enm = new Button[5];
        Button[] blt = new Button[65];
        int i = 1; //for enm[i]
        int j = 1; //for blt[i]
        int x = 2; //for initial location of player
        int score = 0;
        int timer = 60;
        string msg;
        bool blt_shoot = true;


        public Form2()
        {
            InitializeComponent();
            this.p.ply_atb = Form1.atb;
            timer3.Start();//count down 60s
            timer3.Interval = 1000;
        }

        public void color(Button b,int atb)
        {
            if (atb == 1) b.BackColor = Color.Blue;
            else if (atb == 2) b.BackColor = Color.Red;
            else if (atb == 3) b.BackColor = Color.Green;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // we set border margin 20,10
            this.KeyPreview = true;
            player.Text = "P";
            color(player,p.ply_atb);

            size(player, 40);
            panel.Size = new Size(250, 400);
            panel.Location = new Point(20, 10);

            //initialize the first 4 enm btn
            for(int i = 1; i <= 4; i++)
            {
                enm[i] = new Button();
                panel.Controls.Add(enm[i]);               
                p.set_enm_atb(i);
                size(enm[i], 40);                                     
            }
           
            //initialize the location
            player.Location = new Point(70, 310);
            enm[1].Location = new Point(20, 10);
            enm[2].Location = new Point(70, 10);
            enm[3].Location = new Point(120, 10);
            enm[4].Location = new Point(170, 10);

            timer1.Start();      

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            scr_lbl.Text = score.ToString();
            atb_lbl.Text = p.s_atb(p.ply_atb);

            foreach (Button b in panel.Controls)
            {
                if (i > 4) i = 1;
                if (b == player) continue;

                else if (b == enm[i])
                { //produce a new enemy when it hit the ground(y=410)
                    if (b.Top >= 410)
                    {
                        b.Top = 10;
                        p.set_enm_atb(i);
                    }

                    //when player hit enemy
                    else if ((b.Left == player.Left) && (b.Top >= player.Top))
                    {
                        //same attribute
                        if (p.ply_atb == p.enm_atb[i]) score += 0;

                        //supress
                        else if (supress(p.ply_atb, p.enm_atb[i]) == true)
                        {
                            score += 5;
                            b.Top = 10;
                            //change atb when hit enm
                            p.ply_atb = p.enm_atb[i];
                            color(player, p.ply_atb);
                            p.set_enm_atb(i);
                        }

                        //supressed by
                        else
                        {
                            score -= 5;
                            b.Top = 10;
                            p.set_enm_atb(i);
                        }
                    }

                    //move every 0.1s
                    switch (p.enm_atb[i])
                    {
                        case 1: wt.move(b, wt.speed); wt.color(b); break;
                        case 2: fr.move(b, fr.speed); fr.color(b); break;
                        case 3: wd.move(b, wd.speed); wd.color(b); break;
                    }
                    i++;
                }

                //bullet
                else
                {                   
                    //when player hit enemy
                    for (int i = 1; i <= 4; i++)
                    {
                        if( (b.Left-10 == enm[i].Left) && (b.Top <= enm[i].Top))
                        {
                            if (p.blt_atb == p.enm_atb[i]) score += 0;

                            else if (supress(p.blt_atb, p.enm_atb[i])) score += 2;

                            else score -= 2;

                            //bullet disappear
                            enm[i].Top = 10;
                            p.set_enm_atb(i);
                            color(enm[i], p.enm_atb[i]);
                            panel.Controls.Remove(b);
                        }
                    }
                  
                    switch (p.blt_atb)
                    {
                        case 1: wt.shoot(b, wt.speed); wt.color(b); break;
                        case 2: fr.shoot(b, fr.speed); fr.color(b); break;
                        case 3: wd.shoot(b, wd.speed); wd.color(b); break;
                    }
                }
            }

        }
        private void Form2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A)
            {
                x--;
                if (x >= 1) player.Left -= 50;
                else x = 1;
            }
            if (e.KeyCode == Keys.D)
            {
                x++;
                if (x <= 4) player.Left += 50;
                else x = 4;
            }

            if (e.KeyCode == Keys.W)
            {
                timer2.Start();
                timer2.Interval = 1000;
                if (blt_shoot) {
                    blt[j] = new Button();
                    p.blt_atb = p.ply_atb;
                    panel.Controls.Add(blt[j]);
                    size(blt[j], 20);
                    blt[j].Location = player.Location;
                    blt[j].Left += 10;
                    j++;
                    blt_shoot = false;
                }
              
            }
        }
        public void size(Button b, int size)
            {
                b.Size = new Size(size, size);
            }
        public bool supress(int ply_atb, int enm_atb)
            {
                switch (ply_atb)
                {
                    //water
                    case 1:
                        {
                            if (enm_atb == 2) return true;
                            if (enm_atb == 3) return false;
                            break;
                        }
                    //fire
                    case 2:
                        {
                            if (enm_atb == 3) return true;
                            if (enm_atb == 1) return false;
                            break;
                        }
                    //wood
                    case 3:
                        {
                            if (enm_atb == 1) return true;
                            if (enm_atb == 2) return false;
                            break;
                        }
                }
                return false;
            }
            private void timer2_Tick(object sender, EventArgs e)
            {
            blt_shoot = true;
            timer2.Stop();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timer -= 1;
            cd_lbl.Text = timer.ToString();

            if (timer == 0) {
                timer3.Stop();
                timer1.Stop();
                foreach (Button b in panel.Controls) b.Enabled = false;
                MessageBox.Show("GameOver!\nYour score is " + score.ToString());
              }  

            else if (score < 0)
            {
                score = 0;
                scr_lbl.Text = "0";
                switch (p.ply_atb)
                {
                    case 1: msg = "You are drained!";break;
                    case 2: msg = "You are extinguished!"; break;
                    case 3: msg = "You are burning!"; break;
                }
                timer3.Stop();
                timer1.Stop();
                foreach (Button b in panel.Controls) b.Enabled = false;
                MessageBox.Show(msg + "\nYour score is " + score.ToString());
            }
        }
    }
    }

